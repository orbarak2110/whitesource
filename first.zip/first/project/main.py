import os
import json


def get_id(path: str, param: str) -> int:
    """
    the function get 2 parameter, full path and string and return the count of shows inside the json
    :param path: path to the json file
    :param param: the value in the library(inside the json)
    :return: the number of distinct

    >>> import os
    >>>import json
    >>>tail, head = os.path.split(os.getcwd())
    >>>print(get_id('C:\\Users\\orb\\PycharmProjects\\first\\question1.json', "taglibs-2.3.1"))
    3
    """
    with open(path, 'r') as file:
        json_as_dict = json.load(file)
    id_counter = {}

    for item in json_as_dict['Vulnerabilities']:
        if item['library'] == param:
            try:
                id_counter[item['id']] += 1
            except:
                id_counter[item['id']] = 1
    return len(id_counter)


if __name__ == '__main__':
    tail, head = os.path.split(os.getcwd())
    p = os.path.join(tail, 'question1.json')
    param = "taglibs-2.3.1"
    print(get_id(p, param))

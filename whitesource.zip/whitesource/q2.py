import json
import os
from pprint import pprint


def flat(qae_list: list[dict]):
    """
    The function create a flat json. the function will print the new json to the console
    and create new json file(flat_json.json) in the folder of the project (with QAE.json inside the project)

    :param qae_list: Json file after opened
    """

    flat_json = []
    for qae_dict in qae_list:

        if isinstance(qae_dict['children'], list) and len(qae_dict['children']) > 0:
            flat(qae_dict['children'])
        else:
            flat_json.append(qae_dict)



    # Print the new json to the console
    pprint(flat_json)
    # Creating the new json file inside the folder project
    new_file = os.path.join(os.getcwd(), 'flat_json.json')
    with open(new_file, 'w') as f:
        json.dump(flat_json, f)

if __name__ == '__main__':
    with open(os.path.join(os.getcwd(), 'QAE.json'), 'r') as file:
        qae = json.load(file)
    flat(qae)
import json
import os
from pprint import pprint


def remove_keys(qae_list: list[dict]):
    """
    The function deletes all keys that equal to type and filename. the function will print the new json to the console
    and create new json file(without_type_filename.json) in the folder of the project (with QAE.json inside the project)

    :param qae_list: Json file after opened
    """
    for qae_dict in qae_list:
        if 'type' in qae_dict.keys():
            del qae_dict['type']
        if 'filename' in qae_dict.keys():
            del qae_dict['filename']
        for key, var in qae_dict.items():
            if isinstance(var, list) and len(var) > 0:
                remove_keys(qae_dict[key])

    # Print the new json to the console
    pprint(qae_list)
    # Creating the new json file inside the folder project
    new_file = os.path.join(os.getcwd(), 'without_type_filename.json')
    with open(new_file, 'w') as f:
        json.dump(qae_list, f)

if __name__ == '__main__':
    with open(os.path.join(os.getcwd(), 'QAE.json'), 'r') as file:
        qae = json.load(file)
    remove_keys(qae)
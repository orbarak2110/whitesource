a = {'a':[], 'b': 2}
del a['c']
print(a)
